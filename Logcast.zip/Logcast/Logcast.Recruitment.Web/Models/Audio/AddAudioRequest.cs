﻿using Logcast.Recruitment.Shared.Models;
using System;

namespace Logcast.Recruitment.Web.Models.Audio
{
	public class AddAudioRequest
	{
        public Guid FileId { get; set; }
        public static implicit operator MetadataModel(AddAudioRequest a)
        {
            return new MetadataModel
            {
                FileId = a.FileId,
            };
        }
	}
}
