﻿using System;

namespace Logcast.Recruitment.Web.Models.Audio
{
	public class UploadAudioFileResponse
	{
        public Guid Id { get; set; }

    }
}
