﻿using Logcast.Recruitment.DataAccess.Entities;
using System;

namespace Logcast.Recruitment.Web.Models.Audio
{

    public class AudioMetadataResponse
	{
        public Guid Id { get; set; }
        public int AudioBitrate { get; set; }
        public int AudioChannels { get; set; }
        public int AudioSampleRate { get; set; }
        public string MimeType { get; set; }
        public long Duration { get; set; }
        public string Title { get; set; }
        public string Album { get; set; }
        public string Genres { get; set; }
        public string Performers { get; set; }

        public AudioMetadataResponse() { }
        public AudioMetadataResponse(AudioMetadata audioMetadata)
        {
            Id = audioMetadata.Id;
            AudioBitrate = audioMetadata.AudioBitrate;  
            AudioChannels = audioMetadata.AudioChannels;
            AudioSampleRate = audioMetadata.AudioSampleRate;
            MimeType = audioMetadata.MimeType;
            Duration = audioMetadata.Duration;
            Title = audioMetadata.Title;
            Album = audioMetadata.Album;
            Genres = audioMetadata.Genres;
            Performers = audioMetadata.Performers;
        }
	}
}
