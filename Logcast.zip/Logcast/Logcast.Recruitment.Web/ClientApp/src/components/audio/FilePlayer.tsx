import React from 'react'
import { IAudioMetadata } from '../../models/audioMetadata';
import { TPlaybackStatus } from './Player';

interface IProps {
    metadata: IAudioMetadata | null;
    status: TPlaybackStatus;
    onDownloadProgress: (p: number) => void;
    onPlaybackProgress: (p: number) => void;
    onPlaybackStatus: (p: TPlaybackStatus) => void;
}

export const FilePlayer = (props: IProps) => {
    const internalStatus = React.useRef<TPlaybackStatus>(props.status);
    const audioRef = React.useRef<HTMLAudioElement | null>(null);
    const onPlaybackUpdate = (ev: React.SyntheticEvent<HTMLAudioElement>) => {
        let duration = ev.currentTarget.duration;
        let currentTime = ev.currentTarget.currentTime;
        let progress = Math.floor(currentTime / duration * 100);
        props.onPlaybackProgress(progress);
    }

    React.useEffect(() => {
        if (internalStatus.current === props.status) return;
        switch (props.status) {
            case 'paused':
                audioRef.current!.pause();
                internalStatus.current = 'paused';
                break;
            case 'playing':
                audioRef.current!.play();
                internalStatus.current = 'playing';
                break;
            case 'stopped':
                break;
            default:
                break;
        }
    }, [props.status])

    React.useEffect(() => {
        if (props.metadata === null) {
            internalStatus.current = 'stopped';
        } else {
            internalStatus.current = 'stopped';
            props.onPlaybackStatus('stopped');
            props.onDownloadProgress(0);
            props.onPlaybackProgress(0);

            fetch(`/api/audio/stream/${props.metadata.id}`, { method: 'get' })
                .then(async response => {
                    const contentLength = parseInt(response.headers.get('Content-Length') ?? '1');
                    if (response.body === null) throw new Error();
                    const reader = response.body.getReader();
                    const chunks = [];
                    let consumed = 0;
                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) break;
                        chunks.push(value);
                        consumed += value.length;
                        props.onDownloadProgress(Math.floor(consumed / contentLength * 100));
                    }
                    props.onDownloadProgress(100);
                    let buffer = new Uint8Array(consumed);
                    let offset = 0;
                    for (let i = 0; i < chunks.length; i++) {
                        buffer.set(chunks[i], offset);
                        offset += chunks[i].length;
                    }
                    const blob = new Blob(chunks, { type: 'audio/mpeg' });
                    const blobUrl = URL.createObjectURL(blob);
                    audioRef.current!.src = blobUrl;
                    audioRef.current!.play();
                    internalStatus.current = 'playing';
                    props.onPlaybackStatus('playing');
                })
        }
    }, [props.metadata])

    return (
        <audio ref={audioRef} onTimeUpdate={onPlaybackUpdate} style={{ display: 'none' }}>
        </audio>
    );

}
