import * as React from "react";
import { ButtonGroup, Input } from 'reactstrap';
import { IAudioMetadata, IFileMetadata, IMetadata } from "../../models/audioMetadata";
import { AudioFeature } from "./AudioFeature";
import { useAudioPageStyles } from "./audioPage.styles";
import { faBinoculars } from "@fortawesome/free-solid-svg-icons";


import { Button } from '../common/button/Button';
import '../common/button/Button.css';
import './audioPage.animations.css';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Player } from "./Player";

export type TFeature = 'loading' | 'emptyLibrary' | 'library' | 'upload-file' | 'upload-metadata';
export type TPlayerMode = 'stream' | 'file';
interface FileUploadResult {
    fileId: string;
    suggestedMetadata: IMetadata;
}

export const Audio = () => {
    const acceptExtensions = '.aa,.aax,.aac,.aiff,.ape,.dsf,.flac,.m4a,.m4b,.m4p,.mp3,.mpc,.mpp,.ogg,.oga,.wav,.wma,.wv,.webm'
    const { buttonStyle, inputStyle, libraryContentStyle } = useAudioPageStyles();
    const [playerMode, setPlayerMode] = React.useState<TPlayerMode>('file');
    const [feature, setFeature] = React.useState<TFeature>("loading");
    const [library, setLibrary] = React.useState<IAudioMetadata[]>([]);
    const [current, setCurrent] = React.useState<IAudioMetadata | null>(null);
    const [prevNext, setPrevNext] = React.useState<{ hasPrev: boolean, hasNext: boolean }>({ hasPrev: false, hasNext: false });
    const [fileSubmitError, setFileSubmitError] = React.useState<string | null>(null);
    const [file, setFile] = React.useState<File | null>(null);
    const [metadata, setMetadata] = React.useState<IFileMetadata | null>(null);

    React.useEffect(() => {
        fetch('api/audio', { method: 'get' })
            .then(response => response.json())
            .then((lib: IAudioMetadata[]) => {
                if (lib.length === 0) {
                    setFeature('emptyLibrary');
                } else {
                    setLibrary(lib);
                    setFeature('library');
                }
            })
    }, []);

    const durationToHumanFriendly = (millis: number) => {
        let minutes = Math.floor(millis / 60000);
        let seconds = parseInt(((millis % 60000) / 1000).toFixed(0));
        return (
            seconds === 60 ?
                (minutes + 1) + ":00" :
                minutes + ":" + (seconds < 10 ? "0" : "") + seconds
        );
    }

    const onFileSelected = (e: React.SyntheticEvent) => {
        let target = e.target as HTMLInputElement;
        if (target.files === null) {
            setFile(null);
            setFileSubmitError('Please, select a file!');
        } else {
            setFile(target.files[0]);
            setFileSubmitError(null);
        }
    }

    const onUploadRequest = () => {
        if (file === null) {
            setFileSubmitError('Please, select a file!');
        } else {
            const data = new FormData();
            data.append('audioFile', file, file.name);
            fetch('/api/audio/audio-file', { method: 'post', body: data })
                .then(response => response.json())
                .then((uploadResult: FileUploadResult) => {
                    setMetadata({ ...uploadResult.suggestedMetadata, fileId: uploadResult.fileId });
                    setFeature('upload-metadata');
                })
                .catch(() => {
                    setFileSubmitError('Sorry, but this file is not recognized by server.')
                })
        }
    }

    const onMetadataSubmit = () => {
        if (metadata === null) return;
        fetch('/api/audio', { method: 'post', body: JSON.stringify(metadata), headers: { 'Content-Type': 'application/json' } })
            .then(response => {
                if (response.ok) {
                    setLibrary([...library, { ...metadata, id: metadata.fileId }]);
                    setFeature('library');
                }
            })
    }

    const onTrackSelected = (e: React.SyntheticEvent) => {
        e.preventDefault(); e.stopPropagation();

        const trackId = e.currentTarget.getAttribute('track-id');
        if (trackId === null) return;
        const idx = library.findIndex(x => x.id === trackId);

        if (idx === -1) return;
        if (library.length === 1) {
            setPrevNext({ hasPrev: false, hasNext: false });
        }
        setCurrent(library[idx]);
    }

    const handleMetadataChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setMetadata({ ...metadata!, [e.target.name]: e.target.value! });
    }

    const features = [
        <AudioFeature key='loading' feature="loading" currentFeature={feature}>
            <p style={{ color: "gray" }}>Loading library...</p>
        </AudioFeature>,
        <AudioFeature key='emptyLibrary' feature="emptyLibrary" currentFeature={feature}>
            <div>
                <p>Oops, looks like library is empty!</p>
                <p style={{ color: "gray" }}>You can be first to upload a track</p>
                <Button style={{ ...buttonStyle, ...{ marginTop: '18px' } }} onClick={() => setFeature('upload-file')}>Upload</Button>
            </div>
        </AudioFeature>,
        <AudioFeature key='library' feature="library" currentFeature={feature}>
            <div style={{ maxHeight: '600px', overflowY: 'auto' }}>
                {
                    library.map(track => (
                        <div key={track.id} style={libraryContentStyle}>
                            <div track-id={track.id} onClick={onTrackSelected}
                                style={{ height: '80px', width: '80px', backgroundColor: '#f4144a' }}>
                                <FontAwesomeIcon icon={faBinoculars} />
                            </div>
                            <div style={{ flex: 'auto', }}>
                                <p><b>{track.title}</b> - {track.performers}</p>
                                <p>{durationToHumanFriendly(track.duration)}</p>
                            </div>
                        </div>
                    ))
                }
                <Button style={{ ...buttonStyle, ...{ marginTop: '18px' } }} onClick={() => setFeature('upload-file')}>Upload</Button>
            </div>
        </AudioFeature>,
        <AudioFeature key='uplaod-file' feature="upload-file" currentFeature={feature}>
            <div>
                <p>Please, select a file to upload.</p>
                <Input style={inputStyle} type={'file'} name={'file'} onChange={onFileSelected} accept={acceptExtensions} />
                <p style={{ color: 'red' }}>{fileSubmitError}</p>
                <Button style={{ ...buttonStyle, ...{ marginTop: '18px' } }} onClick={onUploadRequest}>Upload</Button>
            </div>
        </AudioFeature>,
        <AudioFeature key='uppload-metadata' feature="upload-metadata" currentFeature={feature}>
            <div>
                <p>This is metadata server parsed.</p>
                <p>You can change it, if you want.</p>
                <p>Title</p>
                <Input style={inputStyle} type={'text'} name={'title'} value={metadata?.title} onChange={handleMetadataChange} />
                <p>Artist(s)</p>
                <Input style={inputStyle} type={'text'} name={'performers'} value={metadata?.performers} onChange={handleMetadataChange} />
                <p>Album</p>
                <Input style={inputStyle} type={'text'} name={'album'} value={metadata?.album} onChange={handleMetadataChange} />
                <p>Genre(s)</p>
                <Input style={inputStyle} type={'text'} name={'genres'} value={metadata?.genres} onChange={handleMetadataChange} />
                <p>MimeType: {metadata?.mimeType}, Bitrate: {metadata?.audioBitrate}</p>
                <p>Channels: {metadata?.audioChannels}, Sample rate: {metadata?.audioSampleRate}</p>
                <p>Duration: {durationToHumanFriendly(metadata?.duration ?? 0)}</p>
                <Button onClick={onMetadataSubmit}>Submit</Button>
            </div>
        </AudioFeature>
    ];

    return (
        <div style={{ height: '100%', position: 'relative' }}>
            <div style={{ height: '60px', width: '100%', textAlign: 'center' }}>
                <ButtonGroup>
                    <Button color={playerMode === 'stream' ? 'red' : 'gray'} onClick={() => setPlayerMode('stream')}>Stream</Button>
                    <Button color={playerMode === 'file' ? 'red' : 'gray'} onClick={() => setPlayerMode('file')}>File</Button>
                </ButtonGroup>
            </div>
            {features}
            {feature === 'library' ?
                <Player mode={playerMode} metadata={current} hasNext={prevNext.hasNext} hasPrev={prevNext.hasPrev} />
                : null}
        </div>
    )
};