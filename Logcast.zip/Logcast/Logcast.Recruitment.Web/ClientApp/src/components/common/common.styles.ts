

export const useColors = () => {
    const red = "#f4134a";

    return {red}
}