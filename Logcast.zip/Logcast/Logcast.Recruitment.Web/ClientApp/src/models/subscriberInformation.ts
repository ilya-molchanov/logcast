export interface SubscriberInformation {
    userId: string;
    name: string;
}