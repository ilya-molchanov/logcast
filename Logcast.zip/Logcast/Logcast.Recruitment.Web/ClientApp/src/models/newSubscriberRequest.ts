﻿export interface NewSubscriberRequest {
    name: string;
    email: string;
}