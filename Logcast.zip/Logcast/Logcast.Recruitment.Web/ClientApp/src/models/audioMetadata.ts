export interface AudioMetadata {
    audioBitrate: number;
    audioChannels: number;
    audioSampleRate: number;
    duration: number;
    title: string;
    album: string;
    genres: string;
    performers: string;
}

export interface IMetadata {
    audioBitrate: number;
    audioChannels: number;
    audioSampleRate: number;
    mimeType: string;
    duration: number;
    title: string;
    album: string;
    genres: string;
    performers: string;
}

export interface IFileMetadata extends IMetadata {
    fileId: string;
}

export interface IAudioMetadata extends IMetadata {
    id: string;
}