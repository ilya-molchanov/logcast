﻿using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Threading.Tasks;
using Logcast.Recruitment.Domain.Services;
using Logcast.Recruitment.Shared.Models;
using Logcast.Recruitment.Web.Models.Audio;
using Logcast.Recruitment.DataAccess.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Linq;
using System.Collections.Generic;
using Logcast.Recruitment.Shared.Exceptions;

namespace Logcast.Recruitment.Web.Controllers
{
    [ApiController]
    [Route("api/audio")]
    public class AudioController : ControllerBase
    {
        private readonly IAudioService _audioService;
        public AudioController(IAudioService audioService)
        {
            _audioService = audioService;
        }

        [HttpPost("audio-file")]
        [SwaggerResponse(StatusCodes.Status200OK, "Audio file uploaded successfully", typeof(FileUpload))]
        [ProducesResponseType(typeof(FileUpload), StatusCodes.Status200OK)]
        public async Task<IActionResult> UploadAudioFile(IFormFile audioFile)
        {
            try
            {
                await using var stream = new MemoryStream();
                await audioFile.CopyToAsync(stream);
                var fileUpload = await _audioService.CreateAudioFile(stream, audioFile.FileName);
                return Ok(fileUpload);
            }
            catch (Exception ex)
            {
                if (ex is CorruptedFileException) return BadRequest("File is corrupted");
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost]
        [SwaggerResponse(StatusCodes.Status200OK, "Audio metadata registered successfully")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Audio file not found")]
        public async Task<IActionResult> AddAudioMetadata([Required][FromBody] MetadataWithFileId request)
        {
            try
            {
                await _audioService.CreateAudioMetadata(request);
                return Ok();
            }
            catch (Exception ex)
            {
                if (ex is FileNotFoundException) return NotFound("Audio file not found");
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpGet]
        [SwaggerResponse(StatusCodes.Status200OK, "All metadatas fetched successfully", typeof(List<AudioMetadataResponse>))]
        [ProducesResponseType(typeof(AudioMetadataResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllMetadatas()
        {
            try
            {
                var metadatas = await _audioService.GetAllMetadatas();
                var dtos = metadatas.Select(x => new AudioMetadataResponse(x)).ToList();
                return Ok(dtos);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("{audioId:Guid}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Audio metadata fetched successfully", typeof(AudioMetadataResponse))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Matadata not found")]
        [ProducesResponseType(typeof(AudioMetadataResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAudioMetadata([FromRoute] Guid audioId)
        {
            try
            {
                var metadata = await _audioService.GetAudioMetadata(audioId);
                return Ok(new AudioMetadataResponse(metadata));
            }
            catch (Exception ex)
            {
                if (ex is AudioMetadataNotFoundException) return NotFound("Metadata not found");
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("stream/{audioId:Guid}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Preview stream started successfully", typeof(FileContentResult))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "Audio not found")]
        [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAudioStream([FromRoute] Guid audioId)
        {
            try
            {
                var stream = await _audioService.GetAudioStream(audioId);
                Response.Headers["Content-Length"] = stream.Item1.Length.ToString();
                Response.Headers["Content-Type"] = stream.Item2;
                return File(stream.Item1, stream.Item2);
                //return File(stream, "application/octet-stream");
            }
            catch (Exception ex)
            {
                if (ex is AudioMetadataNotFoundException) return NotFound("Metadata not found");
                if (ex is AudioFileNotFoundException) return NotFound("Audio file not found");
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}