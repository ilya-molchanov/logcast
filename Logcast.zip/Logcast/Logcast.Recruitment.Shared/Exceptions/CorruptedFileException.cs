﻿using System;

namespace Logcast.Recruitment.Shared.Exceptions
{
    public class CorruptedFileException : Exception
    {
        public CorruptedFileException() : base() { }
        public CorruptedFileException(string message) : base(message) { }
    }
}
