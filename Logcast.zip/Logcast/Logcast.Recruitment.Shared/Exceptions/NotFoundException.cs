using System;

namespace Logcast.Recruitment.Shared.Exceptions
{
    public class NotFoundException : Exception
    {
        
    }
}