﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logcast.Recruitment.Shared.Models
{
    public class MetadataModel
    {
        public Guid FileId { get; set; }
        public string Author { get; set; }
        public string Album { get; set; }
        public TimeSpan Duration { get; set; }
    }
}
