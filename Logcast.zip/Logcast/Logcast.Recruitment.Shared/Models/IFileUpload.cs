﻿using System;

namespace Logcast.Recruitment.Shared.Models
{
    public interface IFileUpload
    {
        Guid FileId { get; set; }
        Metadata SuggestedMetadata { get; set; }
    }

    public class FileUpload : IFileUpload
    {
        public Guid FileId { get; set; }
        public Metadata SuggestedMetadata { get; set; }
    }

}
