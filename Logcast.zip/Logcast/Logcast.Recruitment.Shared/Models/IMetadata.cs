﻿using System;

namespace Logcast.Recruitment.Shared.Models
{
    public interface IMetadata
    {
        int AudioBitrate { get; set; }
        int AudioChannels { get; set; }
        int AudioSampleRate { get; set; }
        string MimeType { get; set; }
        long Duration { get; set; }
        string Title { get; set; }
        string Album { get; set; }
        string Genres { get; set; }
        string Performers { get; set; }
    }

    public class Metadata : IMetadata
    {
        public int AudioBitrate { get; set; }
        public int AudioChannels { get; set; }
        public int AudioSampleRate { get; set; }
        public string MimeType { get; set; }
        public long Duration { get; set; }
        public string Title { get; set; }
        public string Album { get; set; }
        public string Genres { get; set; }
        public string Performers { get; set; }
    }

    public class MetadataWithFileId : Metadata
    {
        public Guid FileId { get; set; }
    }
}
