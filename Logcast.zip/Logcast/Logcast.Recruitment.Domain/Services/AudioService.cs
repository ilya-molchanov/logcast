﻿using Logcast.Recruitment.DataAccess.Entities;
using Logcast.Recruitment.DataAccess.Exceptions;
using Logcast.Recruitment.DataAccess.Repositories;
using Logcast.Recruitment.Shared.Exceptions;
using Logcast.Recruitment.Shared.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Logcast.Recruitment.Domain.Services
{
    public interface IAudioService
    {
        Task<IFileUpload> CreateAudioFile(MemoryStream content, string fileName);
        Task CreateAudioMetadata(MetadataWithFileId metadata);
        Task<List<AudioMetadata>> GetAllMetadatas();
        Task<AudioMetadata> GetAudioMetadata(Guid id);
        Task<(Stream, string)> GetAudioStream(Guid metadataId);

    }
    public class AudioService : IAudioService
    {
        private const string EmptyTag = "Unknown";
        private readonly IMetadataRepository _metadataRepository;
        private readonly IFileRepository _fileRepository;
        private class StreamAbstraction : TagLib.File.IFileAbstraction
        {
            public StreamAbstraction(string name, Stream stream)
            {
                Name = name;
                ReadStream = stream;
                WriteStream = stream;
            }
            public string Name { get; private set; }

            public Stream ReadStream { get; private set; }

            public Stream WriteStream { get; private set; }

            public void CloseStream(Stream stream)
            {
                stream.Dispose();
            }
        }
        public AudioService(IFileRepository fileRepository, IMetadataRepository metadataRepository)
        {
            _fileRepository = fileRepository;
            _metadataRepository = metadataRepository;
        }

        public async Task<IFileUpload> CreateAudioFile(MemoryStream content, string fileName)
        {
            // Fore some reason, TagLibSharp's author does not allow 
            // us to use Stream as input 'file', so using IFileAbstraction
            // implementation will do the trick. Since TagLib disposes stream,
            // it'll recieve a copy of original.
            try
            {
                var streamCopy = new MemoryStream();
                await content.CopyToAsync(streamCopy);

                // Not needed, since ToArray() ignores current stream position.
                // content.Position = 0;

                var virtualFile = new StreamAbstraction(fileName, content);
                var tfile = TagLib.File.Create(virtualFile);
                var metadata = new Metadata
                {
                    AudioBitrate = tfile.Properties.AudioBitrate,
                    AudioChannels = tfile.Properties.AudioChannels,
                    AudioSampleRate = tfile.Properties.AudioSampleRate,
                    MimeType = tfile.MimeType.Replace("taglib", "audio"),
                    Duration = (long)tfile.Properties.Duration.TotalMilliseconds,
                    Title = string.IsNullOrWhiteSpace(tfile.Tag.Title) ? EmptyTag : tfile.Tag.Title,
                    Album = string.IsNullOrWhiteSpace(tfile.Tag.Album) ? EmptyTag : tfile.Tag.Album,
                    Genres = tfile.Tag.Genres.Length == 0 ? EmptyTag : string.Join(",", tfile.Tag.Genres),
                    Performers = tfile.Tag.Performers.Length == 0 ? EmptyTag : string.Join(",", tfile.Tag.Performers)
                    // Album cover?
                };

                var fileUpload = new FileUpload
                {
                    FileId = await _fileRepository.CreateFile(content.ToArray(), fileName),
                    SuggestedMetadata = metadata
                };

                return fileUpload;
            }
            catch (Exception)
            {
                // File seems to be corrupted.
                throw new CorruptedFileException(fileName);
            }
        }

        public async Task CreateAudioMetadata(MetadataWithFileId metadata)
        {
            if (await _fileRepository.Exists(metadata.FileId))
            {
                await _metadataRepository.CreateMetadata(metadata);
            }
            else
            {
                throw new AudioFileNotFoundException();
            }
        }

        public Task<AudioMetadata> GetAudioMetadata(Guid id)
        {
            return _metadataRepository.GetMetadata(id);
        }

        public async Task<(Stream, string)> GetAudioStream(Guid metadataId)
        {
            var metadata = await _metadataRepository.GetMetadata(metadataId);
            var file = await _fileRepository.GetFile(metadata.FileId);
            return (new MemoryStream(file.Content), metadata.MimeType);
        }

        public Task<List<AudioMetadata>> GetAllMetadatas()
        {
            return _metadataRepository.GetAllMetadatas();
        }
    }
}
