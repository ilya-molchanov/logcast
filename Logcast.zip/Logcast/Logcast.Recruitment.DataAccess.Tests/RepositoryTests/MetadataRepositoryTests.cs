﻿using System;
using System.IO;
using System.Threading.Tasks;
using Logcast.Recruitment.DataAccess.Entities;
using Logcast.Recruitment.DataAccess.Exceptions;
using Logcast.Recruitment.DataAccess.Factories;
using Logcast.Recruitment.DataAccess.Repositories;
using Logcast.Recruitment.DataAccess.Tests.Configuration;
using Logcast.Recruitment.Shared.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;


namespace Logcast.Recruitment.DataAccess.Tests.RepositoryTests
{
    [TestClass]
    public class MetadataRepositoryTests
    {
        private readonly IMetadataRepository _metadataRepository;
        private readonly ApplicationDbContext _testDbContext;

        public MetadataRepositoryTests()
        {
            _testDbContext = EfConfig.CreateInMemoryTestDbContext();

            var dbContextFactoryMock = new Mock<IDbContextFactory>();
            dbContextFactoryMock.Setup(d => d.Create()).Returns(EfConfig.CreateInMemoryApplicationDbContext());

            _metadataRepository = new MetadataRepository(dbContextFactoryMock.Object);
        }

        [TestCleanup]
        public void Cleanup()
        {
            _testDbContext.Database.EnsureDeleted();
        }

        [TestMethod]
        public async Task CreateMetadata_FileExists_ShouldCreateMetadata()
        {
            var file = CreateTestFile();
            var metadataWithFileId = CreateTestMetadataWithFileId(file.Id);

            await _testDbContext.Files.AddAsync(file);
            await _testDbContext.SaveChangesAsync();

            var metadata = await _metadataRepository.CreateMetadata(metadataWithFileId);

            AssertMetadataEquals(metadata, metadataWithFileId);
        }

        [TestMethod]
        public async Task CreateMetadata_FileDoesNotExist_ShouldThrowException()
        {
            var fileId = Guid.NewGuid();
            var metadataWithFileId = CreateTestMetadataWithFileId(fileId);

            await Assert.ThrowsExceptionAsync<AudioFileNotFoundException>(() => _metadataRepository.CreateMetadata(metadataWithFileId));
        }

        [TestMethod]
        public async Task DeleteMetadata_MetadataExists_ShouldDeleteMetadata()
        {
            var file = CreateTestFile();
            var metadata = CreateTestMetadata(file.Id);
            await _testDbContext.Files.AddAsync(file);
            await _testDbContext.Metadatas.AddAsync(metadata);
            await _testDbContext.SaveChangesAsync();

            await _metadataRepository.DeleteMetadata(metadata.Id);
            var exists = await _testDbContext.Metadatas.AnyAsync(m => m.Id == metadata.Id);

            Assert.IsFalse(exists);
        }

        [TestMethod]
        public async Task DeleteMetadata_MetadataDoesNotExist_ShouldThrowException()
        {
            var id = Guid.NewGuid();
            await Assert.ThrowsExceptionAsync<AudioMetadataNotFoundException>(() => _metadataRepository.DeleteMetadata(id));
        }

        [TestMethod]
        public async Task GetMetadata_MetadataExists_ShouldReturnMetadata()
        {
            var file = CreateTestFile();
            var metadata = CreateTestMetadata(file.Id);
            await _testDbContext.Files.AddAsync(file);
            await _testDbContext.Metadatas.AddAsync(metadata);
            await _testDbContext.SaveChangesAsync();

            var actual = await _metadataRepository.GetMetadata(file.Id);

            AssertMetadataEquals(metadata, actual);
        }

        [TestMethod]
        public async Task GetMetadata_MetadataDoesNotExist_ShouldThrowException()
        {
            var id = Guid.NewGuid();
            await Assert.ThrowsExceptionAsync<AudioMetadataNotFoundException>(() => _metadataRepository.GetMetadata(id));
        }

        [TestMethod]
        public async Task GetAllMetadatas_MetadataExist_ShouldReturnListOfMetadatas()
        {
            var file = CreateTestFile();
            var metadata = CreateTestMetadata(file.Id);
            await _testDbContext.Files.AddAsync(file);
            await _testDbContext.Metadatas.AddAsync(metadata);
            await _testDbContext.SaveChangesAsync();

            var list = await _metadataRepository.GetAllMetadatas();

            Assert.IsTrue(list.Count > 0);
        }

        [TestMethod]
        public async Task GetAllMetadatas_MetadataDoesNotExist_ShouldReturnEmptyList()
        {
            var list = await _metadataRepository.GetAllMetadatas();

            Assert.IsTrue(list.Count == 0);
        }



        private MetadataWithFileId CreateTestMetadataWithFileId(Guid fileId)
        {
            return new MetadataWithFileId
            {
                FileId = fileId,
                Album = "Test",
                AudioBitrate = 192,
                AudioChannels = 1,
                AudioSampleRate = 41200,
                Duration = 1000,
                Genres = "Test",
                MimeType = "Test",
                Performers = "Test",
                Title = "Test"
            };
        }
        private AudioMetadata CreateTestMetadata(Guid fileId)
        {
            var metadataModel = CreateTestMetadataWithFileId(fileId);
            return new AudioMetadata
            {
                Id = metadataModel.FileId,
                FileId = metadataModel.FileId,
                MimeType = metadataModel.MimeType,
                Album = metadataModel.Album,
                AudioBitrate = metadataModel.AudioBitrate,
                AudioChannels = metadataModel.AudioChannels,
                AudioSampleRate = metadataModel.AudioSampleRate,
                Duration = metadataModel.Duration,
                Genres = metadataModel.Genres,
                Performers = metadataModel.Performers,
                Title = metadataModel.Title,
            };
        }
        private AudioFile CreateTestFile()
        {
            return new AudioFile
            {
                Id = Guid.NewGuid(),
                Content = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 },
                FileName = "text.txt"
            };
        }
        private void AssertMetadataEquals(AudioMetadata actual, MetadataWithFileId expected)
        {
            Assert.AreEqual(expected.FileId, actual.Id);
            Assert.AreEqual(expected.Album, actual.Album);
            Assert.AreEqual(expected.AudioBitrate, actual.AudioBitrate);
            Assert.AreEqual(expected.AudioChannels, actual.AudioChannels);
            Assert.AreEqual(expected.AudioSampleRate, actual.AudioSampleRate);
            Assert.AreEqual(expected.Duration, actual.Duration);
            Assert.AreEqual(expected.Genres, actual.Genres);
            Assert.AreEqual(expected.MimeType, actual.MimeType);
            Assert.AreEqual(expected.Performers, actual.Performers);
            Assert.AreEqual(expected.Title, actual.Title);
        }
        private void AssertMetadataEquals(AudioMetadata expected, AudioMetadata actual)
        {
            Assert.AreEqual(expected.Id, actual.Id);
            Assert.AreEqual(expected.FileId, actual.FileId);
            Assert.AreEqual(expected.AudioBitrate, actual.AudioBitrate);
            Assert.AreEqual(expected.AudioChannels, actual.AudioChannels);
            Assert.AreEqual(expected.AudioSampleRate, actual.AudioSampleRate);
            Assert.AreEqual(expected.MimeType, actual.MimeType);
            Assert.AreEqual(expected.Duration, actual.Duration);
            Assert.AreEqual(expected.Title, actual.Title);
            Assert.AreEqual(expected.Album, actual.Album);
            Assert.AreEqual(expected.Genres, actual.Genres);
            Assert.AreEqual(expected.Performers, actual.Performers);
        }
    }
}
