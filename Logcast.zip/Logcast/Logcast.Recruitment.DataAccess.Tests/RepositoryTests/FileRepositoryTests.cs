﻿using System;
using System.IO;
using System.Threading.Tasks;
using Logcast.Recruitment.DataAccess.Entities;
using Logcast.Recruitment.DataAccess.Exceptions;
using Logcast.Recruitment.DataAccess.Factories;
using Logcast.Recruitment.DataAccess.Repositories;
using Logcast.Recruitment.DataAccess.Tests.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Logcast.Recruitment.DataAccess.Tests.RepositoryTests
{
    [TestClass]
    public class FileRepositoryTests
    {
        private readonly IFileRepository _fileRepository;
        private readonly ApplicationDbContext _testDbContext;

        public FileRepositoryTests()
        {
            _testDbContext = EfConfig.CreateInMemoryTestDbContext();

            var dbContextFactoryMock = new Mock<IDbContextFactory>();
            dbContextFactoryMock.Setup(d => d.Create()).Returns(EfConfig.CreateInMemoryApplicationDbContext());
            _fileRepository = new FileRepository(dbContextFactoryMock.Object);
        }

        [TestCleanup]
        public void Cleanup()
        {
            _testDbContext.Database.EnsureDeleted();
        }

        [TestMethod]
        public async Task CreateFile_ShouldCreateFile()
        {
            var content = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var fileName = "text.txt";
            await _fileRepository.CreateFile(content, fileName);

            var fileInfo = await _testDbContext.Files.SingleAsync();

            Assert.AreEqual(fileInfo.FileName, fileName);
            CollectionAssert.AreEquivalent(fileInfo.Content, content);
        }

        [TestMethod]
        public async Task File_Exists_Exists_ShouldReturnTrue()
        {
            var content = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var fileName = "text.txt";
            var id = await _fileRepository.CreateFile(content, fileName);

            var result = await _fileRepository.Exists(id);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task File_DoesNotExist_Exists_ShouldReturnFalse()
        {
            var id = Guid.NewGuid();

            var result = await _fileRepository.Exists(id);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public async Task File_Exists_GetFile_ShouldReturnFile()
        {
            var content = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var fileName = "text.txt";
            var id = await _fileRepository.CreateFile(content, fileName);

            var fileInfo = await _fileRepository.GetFile(id);

            Assert.AreEqual(fileInfo.FileName, fileName);
            CollectionAssert.AreEquivalent(fileInfo.Content, content);
        }

        [TestMethod]
        public async Task File_DoesNotExist_GetFile_ShouldThowException()
        {
            var id = Guid.NewGuid();

            await Assert.ThrowsExceptionAsync<AudioFileNotFoundException>(() => _fileRepository.GetFile(id));
        }

    }
}
