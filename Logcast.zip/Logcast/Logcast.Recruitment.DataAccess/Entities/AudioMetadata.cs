﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logcast.Recruitment.DataAccess.Entities
{
    public class AudioMetadata
    {
        public Guid Id { get; set; }
        public Guid FileId { get; set; }
        public int AudioBitrate { get; set; }
        public int AudioChannels { get; set; }
        public int AudioSampleRate { get; set; }
        public string MimeType { get; set; }
        public long Duration { get; set; }
        public string Title { get; set; }
        public string Album { get; set; }
        public string Genres { get; set; }
        public string Performers { get; set; }
        public AudioFile File { get; set; }
    }
}
