﻿using Logcast.Recruitment.DataAccess.Entities;
using Logcast.Recruitment.DataAccess.Exceptions;
using Logcast.Recruitment.DataAccess.Factories;
using Logcast.Recruitment.Shared.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logcast.Recruitment.DataAccess.Repositories
{
    public interface IMetadataRepository
    {
        Task<AudioMetadata> CreateMetadata(MetadataWithFileId metadataModel);
        Task<AudioMetadata> GetMetadata(Guid id);
        Task<List<AudioMetadata>> GetAllMetadatas();
        Task DeleteMetadata(Guid id);
    }

    public class MetadataRepository : IMetadataRepository
    {
        private readonly ApplicationDbContext _applicationDbContext;

        public MetadataRepository(IDbContextFactory dbContextFactory)
        {
            _applicationDbContext = dbContextFactory.Create();
        }

        public async Task<AudioMetadata> CreateMetadata(MetadataWithFileId metadataModel)
        {
            var fileExists = await _applicationDbContext.Files.AnyAsync(f => f.Id == metadataModel.FileId);
            if (!fileExists)
            {
                throw new AudioFileNotFoundException();
            }

            var newMetadata = new AudioMetadata
            {
                Id = metadataModel.FileId,
                FileId = metadataModel.FileId,
                MimeType = metadataModel.MimeType,  
                Album = metadataModel.Album,    
                AudioBitrate = metadataModel.AudioBitrate, 
                AudioChannels = metadataModel.AudioChannels,
                AudioSampleRate = metadataModel.AudioSampleRate,
                Duration = metadataModel.Duration,
                Genres = metadataModel.Genres,
                Performers = metadataModel.Performers,
                Title = metadataModel.Title,
            };

            _applicationDbContext.Metadatas.Add(newMetadata);
            await _applicationDbContext.SaveChangesAsync();
            return newMetadata;
        }

        public async Task DeleteMetadata(Guid id)
        {
            var metadata = _applicationDbContext.Metadatas.FirstOrDefault(x => x.Id == id);
            if (metadata == null) throw new AudioMetadataNotFoundException();
            _applicationDbContext.Metadatas.Remove(metadata);
            await _applicationDbContext.SaveChangesAsync();
        }

        public Task<List<AudioMetadata>> GetAllMetadatas()
        {
            return _applicationDbContext.Metadatas.AsNoTracking().ToListAsync();
        }

        public async Task<AudioMetadata> GetMetadata(Guid id)
        {
            var metadata = await _applicationDbContext.Metadatas.FirstOrDefaultAsync(x => x.Id == id);
            if (metadata == null) throw new AudioMetadataNotFoundException();
            return metadata;
        }
    }
}
