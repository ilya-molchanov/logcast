﻿using Logcast.Recruitment.DataAccess.Entities;
using Logcast.Recruitment.DataAccess.Exceptions;
using Logcast.Recruitment.DataAccess.Factories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logcast.Recruitment.DataAccess.Repositories
{
    public interface IFileRepository
    {
        Task<Guid> CreateFile(byte[] content, string fileName);
        Task<AudioFile> GetFile(Guid id);
        Task<bool> Exists(Guid id);
    }
    public class FileRepository : IFileRepository
    {
        private readonly ApplicationDbContext _applicationDbContext;

        public FileRepository(IDbContextFactory dbContextFactory)
        {
            _applicationDbContext = dbContextFactory.Create();
        }

        public async Task<Guid> CreateFile(byte[] content, string fileName)
        {
            var id = Guid.NewGuid();
            var newFile = new AudioFile()
            {
                Id = id,
                Content = content,
                FileName = fileName,
            };
            _applicationDbContext.Files.Add(newFile);
            await _applicationDbContext.SaveChangesAsync();
            return id;
        }

        public Task<bool> Exists(Guid id)
        {
            return _applicationDbContext.Files.AnyAsync(f => f.Id == id);
        }

        public async Task<AudioFile> GetFile(Guid id)
        {
            var file = await _applicationDbContext.Files.FirstOrDefaultAsync(f => f.Id == id);
            if (file == null) throw new AudioFileNotFoundException();
            return file;
        }
    }
}
