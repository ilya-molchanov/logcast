﻿using System;

namespace Logcast.Recruitment.DataAccess.Exceptions
{
    public class EmailAlreadyRegisteredException : Exception
    {
    }
}