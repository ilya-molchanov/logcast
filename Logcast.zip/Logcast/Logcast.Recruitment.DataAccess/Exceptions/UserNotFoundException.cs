﻿using System;

namespace Logcast.Recruitment.DataAccess.Exceptions
{
    public class UserNotFoundException : Exception
    {
    }
}