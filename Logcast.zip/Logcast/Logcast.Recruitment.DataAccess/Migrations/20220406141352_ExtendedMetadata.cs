﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Logcast.Recruitment.DataAccess.Migrations
{
    public partial class ExtendedMetadata : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Author",
                table: "Metadatas",
                newName: "Title");

            migrationBuilder.AlterColumn<long>(
                name: "Duration",
                table: "Metadatas",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(TimeSpan),
                oldType: "time");

            migrationBuilder.AddColumn<int>(
                name: "AudioBitrate",
                table: "Metadatas",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "AudioChannels",
                table: "Metadatas",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "AudioSampleRate",
                table: "Metadatas",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Genres",
                table: "Metadatas",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "MimeType",
                table: "Metadatas",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Performers",
                table: "Metadatas",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AudioBitrate",
                table: "Metadatas");

            migrationBuilder.DropColumn(
                name: "AudioChannels",
                table: "Metadatas");

            migrationBuilder.DropColumn(
                name: "AudioSampleRate",
                table: "Metadatas");

            migrationBuilder.DropColumn(
                name: "Genres",
                table: "Metadatas");

            migrationBuilder.DropColumn(
                name: "MimeType",
                table: "Metadatas");

            migrationBuilder.DropColumn(
                name: "Performers",
                table: "Metadatas");

            migrationBuilder.RenameColumn(
                name: "Title",
                table: "Metadatas",
                newName: "Author");

            migrationBuilder.AlterColumn<TimeSpan>(
                name: "Duration",
                table: "Metadatas",
                type: "time",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");
        }
    }
}
