﻿using System;
using System.IO;
using System.Net.Mail;
using System.Threading.Tasks;
using Logcast.Recruitment.DataAccess.Exceptions;
using Logcast.Recruitment.DataAccess.Repositories;
using Logcast.Recruitment.Domain.Services;
using Logcast.Recruitment.Shared.Exceptions;
using Logcast.Recruitment.Shared.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Logcast.Recruitment.Domain.Tests.ServiceTests
{
    [TestClass]
    public class AudioServiceTests
    {
        private readonly Mock<IFileRepository> _fileRepositoryMock;
        private readonly Mock<IMetadataRepository> _metadataRepositoryMock;
        private readonly AudioService _audioService;

        public AudioServiceTests()
        {
            _fileRepositoryMock = new Mock<IFileRepository>();
            _metadataRepositoryMock = new Mock<IMetadataRepository>();
            _audioService = new AudioService(_fileRepositoryMock.Object, _metadataRepositoryMock.Object);
        }

        [TestMethod]
        [DeploymentItem(@"Audio\white-noise.mp3")]
        public async Task CreateAudioFile_ValidFile_VerifyCalls()
        {
            _fileRepositoryMock.Setup(e => e.CreateFile(It.IsAny<byte[]>(), "white-noise.mp3")).ReturnsAsync(Guid.NewGuid());
            var ms = new MemoryStream();
            var fs = new FileStream(@"ServiceTests\Audio\white-noise.mp3", FileMode.Open);
            await fs.CopyToAsync(ms);
            await fs.DisposeAsync();

            await _audioService.CreateAudioFile(ms, "white-noise.mp3");

            _fileRepositoryMock.Verify(a => a.CreateFile(It.IsAny<byte[]>(), "white-noise.mp3"), Times.Once);

        }

        [TestMethod]
        [DeploymentItem(@"Audio\white-noise-corrupt.mp3")]
        public async Task CreateAudioFile_InvalidFile_NoCalls()
        {
            var ms = new MemoryStream();
            new FileStream(@"ServiceTests\Audio\white-noise-corrupt.mp3", FileMode.Open).CopyTo(ms);

            await Assert.ThrowsExceptionAsync<CorruptedFileException>(() => _audioService.CreateAudioFile(ms, "white-noise-corrupt.mp3"));
            _fileRepositoryMock.Verify(a => a.CreateFile(It.IsAny<byte[]>(), "white-noise-corrupt.mp3"), Times.Never);
        }

        [TestMethod]
        [DeploymentItem(@"Audio\white-noise.mp3")]
        [DoNotParallelize]
        public async Task CreateAudioFile_ValidFile_VerifySuggestedMetadata()
        {
            _fileRepositoryMock.Setup(e => e.CreateFile(It.IsAny<byte[]>(), "white-noise.mp3")).ReturnsAsync(Guid.NewGuid());
            var ms = new MemoryStream();
            new FileStream(@"ServiceTests\Audio\white-noise.mp3", FileMode.Open).CopyTo(ms);

            var fileUpload = await _audioService.CreateAudioFile(ms, "white-noise.mp3");

            Assert.AreEqual("Test", fileUpload.SuggestedMetadata.Title);
            Assert.AreEqual("Test", fileUpload.SuggestedMetadata.Performers);
            Assert.AreEqual("Test", fileUpload.SuggestedMetadata.Album);
            Assert.AreEqual("Test", fileUpload.SuggestedMetadata.Genres);
            Assert.AreEqual(2, fileUpload.SuggestedMetadata.AudioChannels);
            Assert.AreEqual(128, fileUpload.SuggestedMetadata.AudioBitrate);
            Assert.AreEqual(44100, fileUpload.SuggestedMetadata.AudioSampleRate);
            Assert.AreEqual("audio/mp3", fileUpload.SuggestedMetadata.MimeType);
        }


        [TestMethod]
        public async Task CreateMetadata_FileExists_VerifyCalls()
        {
            var id = Guid.NewGuid();
            var metadata = new MetadataWithFileId
            {
                FileId = id,
                Album = "Test",
                AudioBitrate = 192,
                AudioChannels = 1,
                AudioSampleRate = 41200,
                Duration = 1000,
                Genres = "Test",
                MimeType = "Test",
                Performers = "Test",
                Title = "Test"
            };
            _fileRepositoryMock.Setup(e => e.Exists(id)).ReturnsAsync(true);
            await _audioService.CreateAudioMetadata(metadata);
            _metadataRepositoryMock.Verify(a => a.CreateMetadata(metadata), Times.Once);

        }

        [TestMethod]
        public async Task CreateMetadata_FileDoesNotExist_NoCalls()
        {
            var id = Guid.NewGuid();
            var metadata = new MetadataWithFileId
            {
                FileId = id,
                Album = "Test",
                AudioBitrate = 192,
                AudioChannels = 1,
                AudioSampleRate = 41200,
                Duration = 1000,
                Genres = "Test",
                MimeType = "Test",
                Performers = "Test",
                Title = "Test"
            };
            _fileRepositoryMock.Setup(e => e.Exists(id)).ReturnsAsync(false);
            await Assert.ThrowsExceptionAsync<AudioFileNotFoundException>(() => _audioService.CreateAudioMetadata(metadata));
            _metadataRepositoryMock.Verify(a => a.CreateMetadata(metadata), Times.Never);
        }

    }
}
